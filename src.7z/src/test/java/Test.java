import javax.swing.JOptionPane;

public class Test {
    public static void main(String args[]) {
	String tt=JOptionPane.showInputDialog("Gimme some input");
	System.exit(1);
    }
}
