import junit.framework.TestCase;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import static junit.framework.TestCase.assertEquals;

public class TestSort1 extends TestCase
{
    ArrayList lines;

    private ArrayList make123() {
        ArrayList l = new ArrayList();
        l.add("one");
        l.add("two");
        l.add("three");

        return l;
    }


     public void testReadFromStream(BufferedReader d) throws IOException
    {
        Reader in=new FileReader("in.txt");
        StringSorter ss=new StringSorter();
        ArrayList l= make123();

        ss.readFromStream(in);
        assertEquals(l,ss.lines);

    }

}
