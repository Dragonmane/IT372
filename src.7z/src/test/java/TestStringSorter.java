import junit.framework.TestCase;
import java.util.ArrayList;
import java.io.*;

public class TestStringSorter extends TestCase {

	private ArrayList make123() {
		ArrayList l = new ArrayList();
		l.add("one");
		l.add("two");
		l.add("three");

		return l;
	}

	public void testFindIdxBiggest() {
		StringSorter ss=new StringSorter();
		ArrayList l = make123();

		int i=StringSorter.findIdxBiggest(l,0,l.size()-1);
		assertEquals(i,1);
	}

	public void testSwap() {
		ArrayList l1= make123();

		ArrayList l2=new ArrayList();
		l2.add("one");
		l2.add("three");
		l2.add("two");

		StringSorter.swap(l1,1,2);
		assertEquals(l1,l2);
	}

	public void testReadFromStream() throws IOException{
		Reader in=new FileReader("in.txt");
		StringSorter ss=new StringSorter();
		ArrayList l= make123();

		ss.readFromStream(in);
		assertEquals(l,ss.lines);
	}

	public void testSort1() {
		StringSorter ss= new StringSorter();
		ss.lines=make123();

		ArrayList l2=new ArrayList();
		l2.add("one");
		l2.add("three");
		l2.add("two");

		ss.sort();

		assertEquals(l2,ss.lines);
	}

	public void testWriteToStream() throws IOException{
		// write out a known value
		StringSorter ss1=new StringSorter();
		ss1.lines=make123();
		Writer out=new FileWriter("test.out");
		ss1.writeToStream(out);
		out.close();

		// then read it and compare
		Reader in=new FileReader("in.txt");
		StringSorter ss2=new StringSorter();
		ss2.readFromStream(in);
		assertEquals(ss1.lines,ss2.lines);
	}

		public void testSort2() throws IOException{
		// write out a known value
		StringSorter ss1=new StringSorter();
		ss1.sort("in.txt","test2.out");

		ArrayList l=new ArrayList();
		l.add("one");
		l.add("three");
		l.add("two");

		// then read it and compare
		Reader in=new FileReader("test2.out");
		StringSorter ss2=new StringSorter();
		ss2.readFromStream(in);
		assertEquals(l,ss2.lines);
	}

}
